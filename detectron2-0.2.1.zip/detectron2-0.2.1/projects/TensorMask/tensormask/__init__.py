# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
from .config import add_tensormask_config
from .arch import TensorMask
